package com.ants.springbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseApiApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Step - 1 Annotate 
		SpringApplication.run(CourseApiApp.class, args);
	}

}
