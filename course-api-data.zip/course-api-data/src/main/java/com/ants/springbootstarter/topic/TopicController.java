package com.ants.springbootstarter.topic;

import java.lang.reflect.Method;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TopicController {
	
	@Autowired
	private TopicService topicService;
		
	@RequestMapping ("/topics")
	public List<Topic> getAllTopic() {
		return topicService.getAllTopics();
	}
	
	@RequestMapping ("/topics/{id}")
	/* you can write above line as below
	@RequestMapping ("/topics/{foo}")
	by using annotation we are providing the id is this id. 
	*/
	// foo is mapping to String id by using annotation @PathVariable
	public Topic getTopic(@PathVariable("id") String id) {
		return topicService.getTopic(id);
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value="/topics")
	public void addTopic(@RequestBody Topic topic) {
		topicService.addTopic(topic);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value="/topics/{id}")
	public void updateTopic(@RequestBody Topic topic, @PathVariable("id") String id) {
		topicService.updateTopic(id,topic);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value="/topics/{id}")
	public void deleteTopic( @PathVariable("id") String id) {
		topicService.deleteTopic(id);
	}
	
	
}
